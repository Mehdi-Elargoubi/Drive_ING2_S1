import random
import math

def etatInitial(N):
    etat =[]
    for i in range(N) :
        etat.append(random.randint(0, N - 1))
    return etat

def afficher(etat):
    N = len(etat)
    for i in range(N):
        for j in range(N):
            if(etat[j]==i):
                print ("|Q", end="")
            else:
                print("| ", end="")
        print("|")

def evaluer(etat):
    eval = 0
    N = len(etat)
    for i in range(N):
        for j in range(i+1, N):
            if etat[i] == etat[j] or abs(i - j) == abs(etat[i] - etat[j]):#meme ligne ou mme diagonal 
                eval += 1
    return eval


def fitness(etat):#presente la qualitee 
     return 1/(1+ evaluer(etat))

def population_initiale(taille_population, N):
    population = []
    for i in range(taille_population):
       population.append(etatInitial(N))
    return population


def selection(population):
    total =0
    for solution in population :
        total +=fitness(solution)
        r = random.uniform(0, total)
        cumulative_fitness = 0
    for solution in population:
        cumulative_fitness += fitness(solution)
        if cumulative_fitness >= r:
            return solution



def algorithme_genetique(N, taille_population, nombre_generations, taux_mutation):
    population = population_initiale(taille_population, N)
    for generation in range(nombre_generations):
        nouvelle_population = []
        for i in range(taille_population // 2):
            parent1 = selection(population)
            parent2 = selection(population)
            enfant = croisement(parent1, parent2)
            if random.random()<taux_mutation :
                enfant = mutation(enfant)
            nouvelle_population.extend([parent1, parent2, enfant])
            population = nouvelle_population
    solution = max(population, key=fitness)
    return solution
#je doit ajouter mutation et croisement 




e=etatInitial(N=8)
afficher(e)
print("\n l'évaluation : ",evaluer(e))
print(fitness(e))#petit pas bien et si on a 6 attaque ca sera 1/7=0.14

population=population_initiale(5,4)
for individu in population:
    print(individu)
    print(fitness(individu))

parent = selection(population)
print("\n individu selectionné",parent) 

