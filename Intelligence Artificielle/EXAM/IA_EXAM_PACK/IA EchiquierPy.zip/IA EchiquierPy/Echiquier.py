import random
import math

def etatInitial(N):
    etat =[]
    for i in range(N) :
        etat.append(random.randint(0, N - 1))
    return etat

def afficher(etat):
    N = len(etat)
    for i in range(N):
        for j in range(N):
            if(etat[j]==i):
                print ("|Q", end="")
            else:
                print("| ", end="")
        print("|")

def evaluer(etat):
    eval = 0
    N = len(etat)
    for i in range(N):
        for j in range(i+1, N):
            if etat[i] == etat[j] or abs(i - j) == abs(etat[i] - etat[j]):#meme ligne ou mme diagonal 
                eval += 1
    return eval

def RecuitSimuler(N,Temperature,Taux_r):
    #generer un etat initial aleatoire
    etatCourant = etatInitial(N)
    evalution_etat_courant = evaluer(etatCourant)
    meilleur_etat = etatCourant.copy()
    evaluation_meilleur_etat = evalution_etat_courant
    t= Temperature#nbre iteration
    while(t>1):
        etat_voisin = etatCourant.copy()
        etat_voisin[random.randint(0,N-1)] = random.randint(0,N-1)#generer un voisin aleatoire
        evaluation_voisin = evaluer(etat_voisin)
        probability = 1/(math.exp(math.fabs(evaluation_voisin - evalution_etat_courant)/t))
        if(evaluation_voisin < evalution_etat_courant ) or (random.random()<probability):
            etatCourant = etat_voisin
            evalution_etat_courant = evaluation_voisin
        if(evalution_etat_courant < evaluation_meilleur_etat):
            meilleur_etat = etatCourant
            evaluation_meilleur_etat = evalution_etat_courant           
        t = t*Taux_r

    return meilleur_etat,evaluation_meilleur_etat


e=etatInitial(N=8)
afficher(e)
print("\n l'évaluation : ",evaluer(e))
print("\n recuit similer :",RecuitSimuler(8,7,0.9))

solution,evaluation=RecuitSimuler(8,1000000,0.9)
afficher(solution)
print(solution)
print("\n evaluation :",evaluation)

