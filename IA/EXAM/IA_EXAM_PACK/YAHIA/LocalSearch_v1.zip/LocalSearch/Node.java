

import java.util.Random;

class Node {

    
    private int q[];
    private int boardSize;
    private int cost;
    
    Random randomGenerator = new Random();

    public Node(int boardSize) {
     
        this.boardSize = boardSize;
        q = new int[boardSize];
        cost = 0;
        
        for (int i = 0; i < boardSize; i++) {
            q[i] = randomGenerator.nextInt(boardSize);
        
        }
           
        calculateCost();
        
    }

    public Node(int boardSize, int q[]) {
        this.boardSize = boardSize;
        this.q = q;
        cost = 0;
        calculateCost();
    }



    public int getCost() {
       
        return cost;
    }

    public int[] getQueens() {
        return q;
    }
    
   

    public void calculateCost() {
         //TODO 


    }

     
    public Node getBestNeighbor() {

        //TODO
    	 
    	
    	
    	 return null; 
      	 
    }
    
    public Node getRandomNeighbor() {
      
         //TODO
    	 
    	
    	
    	 return null; 
    }
    
    public void show() {
        System.out.println("Total Cost of " + this.getCost());
     
        int q[] = this.q;
       
        System.out.println();
        
        for (int i = 0; i < boardSize; i++) {
        	
            for (int j = 0; j < boardSize; j++) {
            	
               if (q[j] == i) {
                    System.out.print("Q\t");
                } else {
                    System.out.print("*\t");
                }
            }

            System.out.println();
        }
    }
}
